<?php
include('header.html');
require_once('config.php');
echo("<h2>Actualizar pedidos</h2>");

foreach ($conn->query('SELECT * from pedidos where id='.$_GET['id'].';') as $row){
    echo('
<form class="" method="post">
    <div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Email address</label>
  <input type="Producto" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
</div>
<div class="mb-3">
  <label for="exampleFormControlTextarea1" class="form-label">Example textarea</label>
  <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
</div>
</form>
');
}

if ($_SERVER['REQUEST_METHOD']=='POST'){
    $conn->query('DELETE FROM pedidos WHERE id='.$_GET['id'].';');
    header('location:consultar.php');
}
?>

<?php
include('footer.html');
?>