<?php
include('header.html');
require_once('config.php');

echo('<h2>Listado de pedidos - consultar</h2>');
echo("
<table class='table'>
    <tr>
        <td>ID</td>
        <td>Producto</td>
        <td>Unidades</td>
        <td>Fecha del pedido</td>
        <td>Editar</td>
    </tr>
");
foreach ($conn->query('SELECT * FROM pedidos') as $row){
    echo("
    <tr>
        <td>".$row['id']."</td>
        <td>".$row['producto']."</td>
        <td>".$row['unidades']."</td>
        <td>".$row['fecha_pedido']."</td>
        <td><a href='eliminar.php?id=".$row['id']."'><ion-icon name='trash-outline'></ion-icon></a>
        &nbsp&nbsp
        <a href='actualizar.php?id=".$row['id']."'><ion-icon name='reload-outline'></ion-icon></td>
        <td></td>
    </tr>
    
");
}
echo("</table>");

?>

<?php
include('footer.html');
?>