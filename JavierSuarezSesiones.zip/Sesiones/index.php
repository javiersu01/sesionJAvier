<?php
include('header.html');
?>
<h2>Inicio</h2>

<?php
include('footer.html');
?>